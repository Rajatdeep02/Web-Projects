# Project-3-Art-Store
This project is the first step in the creation of an art store website.
