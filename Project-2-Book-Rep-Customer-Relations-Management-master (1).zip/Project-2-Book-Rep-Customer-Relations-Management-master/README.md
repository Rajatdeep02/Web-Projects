# Project-2-Book-Rep-Customer-Relations-Management
This project is the first step in the creation of a CRM website. In this project you will be augmenting the provided page to use semantic HTML5 tags.
